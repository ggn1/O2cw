$(document).ready(aciddrop);
			var move;

			//Function that initializes the object move's 'position' & 'left' attributes
			function first(){
				move=document.getElementById("astroRun");				
				move.style.position='relative';
				move.style.left='0px'; // Sets the distance from the left edge of screnn
				
			}

           //Function that detects the key code & calls the funtion (e is the event object)
			function getKeyAndMove(e){	


				var key_Code=e.keyCode;  //keyCode returns the unicode character code of the key that triggered the 'onkeydown' event 
				
				switch(key_Code){
					
					
					case 39: //right arrow keycode is 39
						moveRight();
						break;
										
				}
			}
			

			// Function that increases the left distance by 5 pixels
			function moveRight(){
				move.style.left=parseInt(move.style.left)+7 +'px'; //parseInt() accepts the string & converts it into an integer  
			}
			

			//Calls the 'first' function at the time of window load (onload event occurs when the object is loaded)
			window.onload=first;
			

//function that causes the acid drop to fall
function aciddrop() 
{
  var p = 0;                   // intial position of drop
  var x = document.getElementById("acid");   //obstaclefall is id of the acid drop
  var y = setInterval(position, 8);    //calls function position() 

  //function to determine position of drop and stop or continue it from falling
  function position() 
 {

    if (p == 295)     //acid drop stops falling after 295px
    {
      clearInterval(y);      //stops setInterval() function from repeating
      
      picblink();            //calls function picblink() 
      if(document.getElementById)

      //hides the acid drop when the astronaut touches it
      document.getElementById("acid").style.visibility= "hidden";
    
      
    }

    else        //acid drop continues falling till 295px are covered
    {
      p++; 
      x.style.top = p + "px"; 
      x.style.down = p + "px"; 
     
    }

  }

}


//function that causes the astronaut to blink when acid touches
function picblink() 
{

  //astronauts fades
  function fade()
  {
    if(document.getElementById)
    document.getElementById("astroRun").style.visibility= "hidden";

  }


  //astronaut appears
  function appear() 
  {
    if(document.getElementById)
    document.getElementById("astroRun").style.visibility = "visible";
  }
  
  
  //calls fade() and appear() every 450 milliseconds 
  //ends after 2000 milliseconds
  for(var i=0; i < 2000; i=i+900)
{
	setTimeout(fade,i);
	setTimeout(appear,i+450);
}
}