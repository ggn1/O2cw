function aciddrop() 
{
  var p = 0;
  var x = document.getElementById("obstaclefall");   
  var y = setInterval(position, 3);
  function position() 
 {
    if (p == 275) 
    {
      clearInterval(y);
      picchange();
    }
    else 
    {
      p++; 
      x.style.top = p + "px"; 
      x.style.down = p + "px"; 
     
    }
  }
}

function picchange()
{
   document.getElementById("runningman").src ="../images_harini/astronaut_dead.png";
}
