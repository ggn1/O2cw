// MODULES REQUIRED
const express = require('express');
const socket = require('socket.io');
const dbConnection = require('./serverSide/connectDB');

// SETTING UP APP
const app = express();
var portNumber = 3000;

// STATIC FILES
app.use(express.static('./clientSide'));
app.use(express.static('./game'));

// SERVER
const server = app.listen(portNumber, function(){
    console.log("Listening to port 3000")
});

// TO LOAD LOGIN PAGE ON BROWSER

app.get('/', function(req, res){
    res.sendFile(__dirname + 'clientSide/index.html');
});

// TO LOAD GAME PAGE ON BROWSER
app.get('/game', function(req, res){
    res.sendFile(__dirname + "/game/html/indexGame.html");
});

// TO REDIRECT TO GAME PAGE
app.post('/game/submit', function(req,res){
    res.redirect('/game');
});

// CONNECTING TO DB
dbConnection.connectToDB();

// CONNECTING USING SOCKET
var io = socket(server);
io.sockets.on('connection', function(socket){
    console.log("Made socket connection.", socket.id);

    socket.on('addPlayerNameToDB', function(data){
        dbConnection.insertNameIntoTable(data.name, "recent").then(function(data){
            console.log(data);
        });
    });

    socket.on('addIdToPlayer', function(){
        dbConnection.insertIdIntoTable(socket.id).then(function(data){
            console.log(data);
            dbConnection.getPlayerCount().then(function(data){
                io.sockets.emit('updatePlayerCount', {count: data});
            })
        });
    });

    socket.on('getCountAgain', function(){
        dbConnection.getPlayerCount().then(function(data){
            io.sockets.emit('updatePlayerCount', {count: data});
        })
    });

    socket.on('isDead', function(socketID){
        dbConnection.getLoser(socketID.socketId).then(function(loserString){
            io.sockets.emit('displayLoser', {loser: loserString});
            dbConnection.deleteFromTable(socketID.socketId).then(function(deletedString){
                console.log(deletedString);
                dbConnection.getPlayerCount().then(function(numOfPlayers){
                    if(numOfPlayers == 1){
                        dbConnection.getWinner().then(function(winnerString){
                            io.sockets.emit('declareWinner', {message: winnerString});

                            dbConnection.clearDB().then(function(dbClearedString){
                                console.log(dbClearedString);
                            });
                        });
                    }
                    else{
                        io.sockets.emit('updatePlayerCount', {count: numOfPlayers});
                    }
                })
            });
        });
    });
});
