var myHost = "localHost";
var myUser = "root";
var myPassword = "";
var myDatabase = "players";

var db = require('mysql');

var con = db.createConnection(
     {
        host:myHost,
        user:myUser,
        password:myPassword,
        database:myDatabase
    }
);

function connectToDB(){
    con.connect(function(err){
        if(!err) {
            console.log("Connected to db " + myDatabase + ".");    
        } else {
            console.log("Error connecting database.");    
        }
    });
}

function insertNameIntoTable(nameToAdd, recent){
    return new Promise(function(resolve, reject){
        var myQuery = "INSERT INTO `players_table`(`recent`, `username`, `isAlive`) "
                    + "VALUES ('" + recent +"'," + "'" + nameToAdd + "',1)";
        con.query(myQuery);
       resolve("inserted " + nameToAdd + " into table.");
    });
}

function insertIdIntoTable(id){
    return new Promise(function(resolve, reject){
        var myQuery = "UPDATE `players_table` SET `recent` = '',"
                        + "`socketId`= '" + id + "' WHERE `recent` = 'recent'";
        con.query(myQuery);
        resolve("updated socketId to " + id + " in table.");
    })
}

function deleteFromTable(socketID){
    return new Promise(function(resolve, reject){
        var myQuery = "DELETE FROM `players_table` WHERE socketId = '" 
                    + socketID + "'";
        con.query(myQuery);
        resolve("deleted " + socketID + " from table.");
    });
}

function getPlayerCount(){
    return new Promise(function(resolve, reject){
        var myQuery = "SELECT COUNT(username) AS playersCount FROM players_table";
        var count = con.query(myQuery, function(err, result) {
            res = result[0].playersCount;
            resolve(res);
        });
    })
}

function getWinner(){
    return new Promise(function(resolve, reject){
        var myQuery = "SELECT username AS winner FROM `players_table`";
        var count = con.query(myQuery, function(err, result) {
            res = result[0].winner;
            resolve(res.toString() + " is the sole surviver." 
                        + "<br>Congratulations " + res.toString()
                        + "!<br>You are the winner!");
        });
    })
}

function getLoser(socketId){
    return new Promise(function(resolve, reject){
        var myQuery = "SELECT username AS loser FROM `players_table` WHERE socketId = '"
                        + socketId + "'";
        var count = con.query(myQuery, function(err, result) {
            if(!(result[0] == undefined)){
            res = result[0].loser;
            resolve(res.toString() + " just died.")
            }
        });
    })
}

function clearDB(){
    return new Promise(function(resolve, reject){
        var myQuery = "DELETE FROM `players_table`";
        con.query(myQuery, function(err, result){
            if(err){
                resolve("Could not clear db.");
            }
            else{
                resolve("Cleared db.");
            }
        });
    });
}

module.exports.connectToDB = connectToDB;
module.exports.insertNameIntoTable = insertNameIntoTable;
module.exports.insertIdIntoTable = insertIdIntoTable;
module.exports.deleteFromTable = deleteFromTable;
module.exports.getPlayerCount = getPlayerCount;
module.exports.getWinner = getWinner;
module.exports.getLoser = getLoser;
module.exports.clearDB = clearDB;
