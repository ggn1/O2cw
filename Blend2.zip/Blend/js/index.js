/* GUY & FRAME *****************************************************************************/
// Global Variables

var astroLeft = 30;	//stores the position of the astronaut from the left of the div in px (x-coord). 

var astroBottom = 0; //stores the position of the astronaut from the bottom of the div (y-coord) 

var astronaut = document.getElementById("astronaut");	//The astronaut 

var canSlide = true // variable to indicate if the astronaut can slide. Used to avoid spamming the down arrow key.

var isDead = false // variable to indicate if the astronaut is dead or not.

// Function Declarations

// Function to change the picture of the astronaut to him sliding and his dimensions. 

function slide()
{
	astronaut.src = "../images/slide.png";
	astronaut.style.height = 70 + "px";
	astronaut.style.width = 100 + "px";
	canSlide = false;	// sliding is blocked till the astronaut finishes sliding.
}

// Function to reset the astronaut's picture and dimensions after sliding.

function reset() 
{
	astronaut.src = "../images/running.gif";
	astronaut.style.height = 100 + "px";
	astronaut.style.width = 70 + "px";
	canSlide = true;	//the astronaut can slide again now
}

 
// Function to make the astronaut jump and return back to the ground.

function ascend_Descend()
{
	/*The ID value returned by setInterval() is used as the parameter for the clearInterval() method and is
	stored by timerID. The setInterval method calls jump every millisecond. 
	*/

	let timerID = setInterval(jump,1);
	
	/**
		Function to make the astronaut jump. The astronaut's y-coord increases by 1 every millisecond till 
		it reaches 150. Once y coord is 100 the descend function is called.
	*/
	
	function jump ()
	{
		//If the y-coord of the astronaut is 150 then stop the timer (stop executing the jump function).
		if(astroBottom == 150)
		{
			clearInterval(timerID);
			timerID = setInterval(descend,1);
		}	

		else
		{
			astroBottom++;	//increment the y-coord
			astronaut.style.bottom = astroBottom + "px"; //change the astornaut's y-coord 
		}

	}

	/**
		Function to make the astronaut return to the ground after jumping.
		The astronaut's y-coord decreases by 1 every millisecond till it reaches 0.
	*/

	function descend()
	{
		if(astroBottom == 0)
			clearInterval(timerID);
		else
		{
			astroBottom--;	//decrement the y-coord
			astronaut.style.bottom = astroBottom + "px"; //change the astornaut's y-coord
		}
	}	
}

// Function to make the astronaut dash and return back.

function dash_Return()
{
	/* timerID stores the ID returned from the setInterval method.
		The setInterval method calls dash every five milliseconds. 
	*/

	let timerID = setInterval(dash,5);

	/**
		The astronaut's x-coord increases by 1 every 5 millisecs till it reaches 150.
		Once x coord is 150 the returnBack function is called.
	*/

	function dash ()
	{
		//If the x-coord of the astronaut is 150 then stop the timer (stop executing the dash function).
		if(astroLeft == 150)
		{
			clearInterval(timerID);
			timerID = setInterval(returnBack,5);
		}				
		else
		{
			astroLeft++;	//increment the x-coord
			astronaut.style.left = astroLeft + "px"; //change the astornaut's x-coord 
		}

	}

	//The astronaut's x-coord decreases by 1 every 5 millisecs till it reaches 0.
	
	function returnBack()
	{
		
		if(astroLeft == 30)
			clearInterval(timerID);
		else
		{
			astroLeft--;	//decrement the x-coord
			astronaut.style.left = astroLeft + "px"; //change the astornaut's x-coord
		}
	}
}

// Function to handle keypress events.

function animate(e)
{
	if(isDead != true){
		if(e.keyCode == 38)		//Up arrow key is pressed
	{
		
		// Up arrow key will work only if the y coord is zero and x coord is 30.
		if(astroBottom == 0 && astroLeft == 30)	
		{	
			reset(); 				// This is to reset the astronaut if he suddenly jumps while sliding.
			ascend_Descend();		// Move the astronaut.
		}

	}
	if(e.keyCode == 39)		//Right arrow key is pressed
	{
		
		// Right arrow key will work only if the x coord is 30 and y coord is zero.
		if(astroLeft == 30 && astroBottom == 0)
		{
			reset();		// This is to reset the astronaut if he suddenly dashes while sliding.
			dash_Return();	// Make the astronaut dash.
		}	
	}

	if(e.keyCode == 40)		//down arrow key
	{
		//astronaut can duck at initial coordinates and when canSlide = true.
		if(canSlide && (astroLeft == 30 && astroBottom == 0)) 
		{
			slide();	//astronaut slides for 0.75 secs.
			let timerID = setTimeout(reset,750); //timerID stores the ID returned by setTimeout().
		}
	}
	}
	
}

// Add an event listener to respond to the user pressing a directional key.
document.addEventListener("keydown", animate);

/* OBSTACLES *******************************************************************************/
var obstacles = ["url(../images/rock.png)", "url(../images/leech.png)"];

var guyLeft = 0;

var objectRight = 0;
var objectLeft = 0;
var objectTop = 0;

$(document).ready(startMotion);

function startMotion(){
	if(objectRight >= 100){
		resetObstacle();
	}	
	else{
		is_collision();
	}
}

function moveObstacle(){
	// Get current positions
	objectRight = objectRight + 1.2;
	// objectLeft = document.getElementById("obstacles").offsetLeft;
	// objectTop = document.getElementById("obstacles").offsetTop;

	// Store positions	
	// horizontal movment
	document.getElementById("obstacles").style.right = objectRight + "%";
	setTimeout(startMotion, 30);
	
}

function resetObstacle(){
	setRandomHeight();
	$("#obstacles").css("right", "-30%");
	objectRight = 0;
	setTimeout(startMotion, 1000);
}

function setRandomHeight(){
	let heightVal = Math.floor(Math.random()*51 + 40);
	let heightString = heightVal + "%";

	let imageVal = Math.floor(Math.random()*3);
	let imageString = obstacles [imageVal];

	$("#obstacles").css("background-image", imageString);

	$("#obstacles").css("top", heightString);
}

/* O2 BAR **********************************************************************************/
class o2Bar {
	
		/* Fields:
		element valueElem -> Stores the progress bar's Oxygen value object.
		element fillElem -> Stores the colored fill bar object inside the progress bar.
		int value -> stores the new values of the bar.*/

	constructor (element){
		this.valueElem = element.querySelector('.progress-bar-value');
		this.fillElem = element.querySelector('.progress-bar-fill');

		this.set_value(100); //Bar is set to 100% Oxygen as game begins.
	}

	set_value (newValue) { //Method that sets the new value of the progress bar.
		if(newValue > 100){
			newValue = 100;
			}

		if(newValue < 0){
			newValue = 0;
			}

		this.value = newValue

		this.update();
	}

	update() { //Method that updates the progress bar to display the new value and fill bar width.
		const o2label = "Oxygen : "
		const percentage = this.value + '%';

		this.fillElem.style.width = percentage;
		this.valueElem.textContent = o2label + percentage;

		this.bar_color();

		this.kill_if();
	}

	bar_color(){ //Method that changes the bar's color according to value.
		if(this.value <= 10){
			this.fillElem.style.background = "red";
		}
		else if(this.value <= 40){
			this.fillElem.style.background = "yellow";
		}
	}

	kill_if(){  //Method that kills astronaut when death condition is met.
		if(this.value == 0){
			die();
		}
	}	
}

var o2BarReductionVal = 2 // Amount by which to reduce the O2 bar upon collision

/*Creating an object pb, of ProgressBar class.*/	
const pb = new o2Bar(document.querySelector('.progress-bar'));

/* COLLISION DETECTION *****************************************************************/

// Method that detects if there is a collision and rduces O2 Bar if there is.
function is_collision(){
	if(isDead != true){
		moveObstacle();
		console.log(objectRight);
		console.log(astroLeft + 100);
		if( (100 - ((astroLeft/10)+1)) <= objectRight){
			pb.set_value(pb.value - o2BarReductionVal);
		}
	}
}

function die(){ //Method that causes astronaut's death when 0% Oxygen level reached.
	astronaut.src = "../images/dead.png";
	astronaut.style.height = "100px";
	astronaut.style.width = "auto";
	isDead = true;
	alert('Oxygen : 0 % - Your dead!');
}
