var username;

// MAKE SOCKET CONNECTION
var socket = io.connect();

function changeBody() {
    username = $("#nameInput").val();
    socket.emit('addPlayerNameToDB', {name: username});
}

// EMIT EVENT
$('#joinButton').on('click', changeBody);
