// MODULES REQUIRED
const express = require('express');
const socket = require('socket.io');
const dbConnection = require('./connectDB');

// SETTING UP APP
const app = express();
var portNumber = 3000;

// STATIC FILES
app.use(express.static('../clientSide'));
app.use(express.static('../game'));

// SERVER
const server = app.listen(portNumber, function(){
    console.log("Listening to port 3000")
});

// TO LOAD LOGIN PAGE ON BROWSER
app.get('/', function(req, res){
    res.sendFile('D:/HWU/BACHELOR OF COMPUTER SCIENCE HONORS/YEAR 2/SEMESTER1/WEB PROGRAMMING/CourseWork/db_gayathri/clientSide/index.html');
});

// TO LOAD GAME PAGE ON BROWSER
app.get('/game', function(req, res){
    res.sendFile("D:/HWU/BACHELOR OF COMPUTER SCIENCE HONORS/YEAR 2/SEMESTER1/WEB PROGRAMMING/CourseWork/db_gayathri/game/html/indexGame.html");
});

// TO REDIRECT TO GAME PAGE
app.post('/game/submit', function(req,res){
    res.redirect('/game');
});

// CONNECTING TO DB
dbConnection.connectToDB();

// CONNECTING USING SOCKET
var io = socket(server);
io.sockets.on('connection', function(socket){
    console.log("Made socket connection.", socket.id);

    socket.on('addPlayerNameToDB', function(data){
        dbConnection.insertNameIntoTable(data.name, "recent");
    });

    socket.on('addIdToPlayer', function(){
        dbConnection.insertIdIntoTable(socket.id).then(function(data){
            console.log(data);
            dbConnection.getPlayerCount().then(function(data){
                io.sockets.emit('updatePlayerCount', {count: data});
            })
        });
    });

    socket.on('isDead', function(data1){
        dbConnection.deleteFromTable(data1.socketId).then(function(data2){
            console.log(data2);
            dbConnection.getPlayerCount().then(function(data3){
                if(data3 == 1){
                    dbConnection.getWinner().then(function(data4){
                        io.sockets.emit('declareWinner', {message: data4});
                    })
                }
                else{
                    io.sockets.emit('updatePlayerCount', {count: data3.toString()});
                }
            })
        });
    });
});
