var username; //Variable for storing the variable name

// MAKE SOCKET CONNECTION
var socket = io.connect();

// Function that retrives the username
// entred by the gamer and emits an event to the
// server side requesting it to add the username to the database.
function changeBody() {
    username = $("#nameInput").val();
    socket.emit('addPlayerNameToDB', {name: username});
}

// Emit event on clicking the submit button
$('#joinButton').on('click', changeBody);
