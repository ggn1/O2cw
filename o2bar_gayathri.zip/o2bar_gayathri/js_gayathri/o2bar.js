
class ProgressBar {
		/* Fields:
		element valueBar -> Stores the progress bar's Oxygen value object.
		element fillBar -> Stores the colored fill bar object inside the progress bar.
		int value -> stores the new values of the bar.*/

	constructor (element){
		this.valueElem = element.querySelector('.progress-bar-value');
		this.fillElem = element.querySelector('.progress-bar-fill');

		this.set_value(100); //Bar is set to 100% Oxygen as game begins.
	}

	set_value (newValue) { //Method that sets the new value of the progress bar.
		if(newValue > 100){
			newValue = 100;
			}

		if(newValue < 0){
			newValue = 0;
			}

		this.value = newValue

		this.update();
	}

	update() { //Method that updates the progress bar to display the new value and fill bar width.
		const o2label = "Oxygen : "
		const percentage = this.value + '%';

		this.fillElem.style.width = percentage;
		this.valueElem.textContent = o2label + percentage;

		this.bar_color();

		this.kill_if();
	}

	bar_color(){ //Method that changes the bar's color according to value.
		if(this.value <= 10){
			this.fillElem.style.background = "red";
		}
		else if(this.value <= 40){
			this.fillElem.style.background = "yellow";
		}
	}

	kill_if(){  //Method that kills astronaut when death condition is met.
		if(this.value == 0){
			die();
		}
	}	
}
	/*Creating an object pb, of ProgressBar class.*/	
	const pb = new ProgressBar(document.querySelector('.progress-bar'));

/* COLLISION DETECTION *****************************************************************/

var astronaut = document.getElementById('astronaut');
var rock = document.getElementById('rock');

var leftValGuy = 0;
var rightValGuy = 0;

var leftValRock = 200;

var moveVal = 10; //Number of pixels astronaut moves on pressing arrow keys.
var knockBackVal = 50; //Number of pixels astronaut gets knocked back upon collision.
var progressBarReductionVal = 10; //% by which progress bar gets reduced upon collision.

/*Sets the left value of rock in css.*/
window.addEventListener("load", function(){ rock.style.left = leftValRock + "px"});

/*To cause astronaut movement.*/
window.addEventListener("keydown", move);

function move(e){ //Method that moves the astronaut on pressing arrow keys if he is alive.
	if(is_alive()){
		switch(e.keyCode){
			case 39:
				move_right();
				break;

			case 37:
				move_left();
				break;
		}
	}
}

function move_right(){ //Method that moves the astronaut 10px to the right.
	leftValGuy = leftValGuy + moveVal;
	rightValGuy = rightValGuy + moveVal;
	astronaut.style.left = leftValGuy + "px";

	if(is_collision()){
		collision_reaction();
	}
}

function move_left(){ //Method that moves the astronaut 10px to the right.
	if(leftValGuy < 0){ 
		rightValGuy = leftValGuy = 0;
	}

	leftValGuy = leftValGuy - moveVal;
	rightValGuy = rightValGuy - moveVal;
	astronaut.style.left = leftValGuy + "px";
}

function is_collision(){
	if(rightValGuy < (leftValRock - 80)){
		return false;
	} else { return true; }
}

function collision_reaction(){ //Method that decreases Oxygen and knocks back astronaut 50px upon collision.
	leftValGuy = leftValGuy - knockBackVal;
    rightValGuy = rightValGuy - knockBackVal;
	astronaut.style.left = leftValGuy + "px";
	pb.set_value(pb.value - progressBarReductionVal);
}

function die(){ //Method that causes astronaut's death when 0% Oxygen level reached.
	astronaut.src = "../images_gayathri/dead.png";
	astronaut.style.height = "100px";
	astronaut.style.width = "auto";
	
	alert('Oxygen : 0 % - Your dead!');
}

function is_alive(){ //Method that return true when astronaut is still alive.
	if(pb.value == 0){
		return false;
	}
	return true;
}


