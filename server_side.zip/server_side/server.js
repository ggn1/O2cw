var express = require('express')
const app = express()
const path = require('path')

app.use(express.static(__dirname + '/BlendCopy'))
app.get("/",(req,res) => 
  res.sendFile("index.html",{root: path.join(__dirname, './BlendCopy/html')})
)
app.listen(8081)
console.log("Server at 8080");