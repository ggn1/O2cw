var db = require("mysql");

const con = db.createConnection(
{ host:"localhost",
    user:"root",
    password:"",
    database:"players"
}
);

con.connect(function(err) {
    if(err)
        throw err;
    console.log("Connected");
});

function insertIntoTable()
{
    con.query("insert into players_table values ('Wesley',true)", function(err, result)
    {
        if(err)
            throw err;
        console.log(result);
    });
}
//insertIntoTable();

function selectFromTable()
{
    con.query("select * from players_table", function(err, result)
    {
        if(err)
            throw err;
        console.log(result);
    });
}

//selectFromTable();

function deleteAllFromTable()
{
    con.query("delete from players_table", function(err, result)
    {
        if(err)
            throw err;
        console.log(result);
    });
}

function deleteDeadFromTable()
{
    con.query("delete from players_table where isAlive = false", function(err, result)
    {
        if(err)
            throw err;
        console.log(result);
    });
}

function killPlayers()
{
    con.query("update players_table set isAlive = false", function(err, result)
    {
        if(err)
            throw err;
        console.log(result);
    });
}

killPlayers()
deleteDeadFromTable()
