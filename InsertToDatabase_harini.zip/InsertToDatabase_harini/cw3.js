var express = require('express');
var mysql = require('mysql');
var app = express();
const dataparser= require ("body-parser");
const urlencodedParser = dataparser.urlencoded({extended: false});

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'players' 
});

connection.connect(function(error)
{
    if(!!error)
    {
        console.log(error);
    }
    else
    {
        console.log('connection successful');

    }
});

app.get('/', function(request,response)
{
    response.sendFile('cw3.html',{root: __dirname});




   connection.query("SELECT count(*) as total FROM playerdetails",function(error,result)
    {
        if(!!error)
        {
            console.log(error);
        }
        else
        {
            console.log('success');
            console.log("Players remaining:"+ result[0].total);
        
        }
    })
})

app.post('/add_data', urlencodedParser, function(request,response)
{
    var sql= "INSERT INTO playerdetails VALUES( ' "+ request.body.name +" ' , 'Alive' )";
    connection.query(sql,function(error,result)
    {
        if(!!error)
        {
            console.log(error);
        }
        else
        {
            console.log('Data added');
        }
    })
})



app.listen(1337);