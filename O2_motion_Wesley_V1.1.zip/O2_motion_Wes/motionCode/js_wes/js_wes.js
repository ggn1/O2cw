
// Global Variables

var astroLeft = 30;	//stores the position of the astronaut from the left of the div in px (x-coord). 

var astroBottom = 0; //stores the position of the astronaut from the bottom of the div (y-coord) 

var astronaut = document.getElementById("astronaut");	//The astronaut 

var canSlide = true // variable to indicate if the astronaut can slide. Used to avoid spamming the down arrow key.


// Function Declarations

// Function to change the picture of the astronaut to him sliding and his dimensions. 

function slide()
{
	astronaut.src = "../../images_wes/slide.png";
	astronaut.style.height = 70 + "px";
	astronaut.style.width = 100 + "px";
	canSlide = false;	// sliding is blocked till the astronaut finishes sliding.
}

// Function to reset the astronaut's picture and dimensions after sliding.

function reset() 
{
	astronaut.src = "../../images_wes/running.gif";
	astronaut.style.height = 100 + "px";
	astronaut.style.width = 70 + "px";
	canSlide = true;	//the astronaut can slide again now
}

 
// Function to make the astronaut jump and return back to the ground.

function ascend_Descend()
{
	/*The ID value returned by setInterval() is used as the parameter for the clearInterval() method and is
	stored by timerID. The setInterval method calls jump every millisecond. 
	*/

	let timerID = setInterval(jump,1);
	
	/**
		Function to make the astronaut jump. The astronaut's y-coord increases by 1 every millisecond till 
		it reaches 150. Once y coord is 100 the descend function is called.
	*/
	
	function jump ()
	{
		//If the y-coord of the astronaut is 150 then stop the timer (stop executing the jump function).
		if(astroBottom == 150)
		{
			clearInterval(timerID);
			timerID = setInterval(descend,1);
		}	

		else
		{
			astroBottom++;	//increment the y-coord
			astronaut.style.bottom = astroBottom + "px"; //change the astornaut's y-coord 
		}

	}

	/**
		Function to make the astronaut return to the ground after jumping.
		The astronaut's y-coord decreases by 1 every millisecond till it reaches 0.
	*/

	function descend()
	{
		if(astroBottom == 0)
			clearInterval(timerID);
		else
		{
			astroBottom--;	//decrement the y-coord
			astronaut.style.bottom = astroBottom + "px"; //change the astornaut's y-coord
		}
	}	
}

// Function to make the astronaut dash and return back.

function dash_Return()
{
	/* timerID stores the ID returned from the setInterval method.
		The setInterval method calls dash every five milliseconds. 
	*/

	let timerID = setInterval(dash,5);

	/**
		The astronaut's x-coord increases by 1 every 5 millisecs till it reaches 150.
		Once x coord is 150 the returnBack function is called.
	*/

	function dash ()
	{
		//If the x-coord of the astronaut is 150 then stop the timer (stop executing the dash function).
		if(astroLeft == 150)
		{
			clearInterval(timerID);
			timerID = setInterval(returnBack,5);
		}				
		else
		{
			astroLeft++;	//increment the x-coord
			astronaut.style.left = astroLeft + "px"; //change the astornaut's x-coord 
		}

	}

	//The astronaut's x-coord decreases by 1 every 5 millisecs till it reaches 0.
	
	function returnBack()
	{
		
		if(astroLeft == 30)
			clearInterval(timerID);
		else
		{
			astroLeft--;	//decrement the x-coord
			astronaut.style.left = astroLeft + "px"; //change the astornaut's x-coord
		}
	}
}

// Function to handle keypress events.

function animate(e)
{
	if(e.keyCode == 38)		//Up arrow key is pressed
	{
		
		// Up arrow key will work only if the y coord is zero and x coord is 30.
		if(astroBottom == 0 && astroLeft == 30)	
		{	
			reset(); 				// This is to reset the astronaut if he suddenly jumps while sliding.
			ascend_Descend();		// Move the astronaut.
		}

	}
	if(e.keyCode == 39)		//Right arrow key is pressed
	{
		
		// Right arrow key will work only if the x coord is 30 and y coord is zero.
		if(astroLeft == 30 && astroBottom == 0)
		{
			reset();		// This is to reset the astronaut if he suddenly dashes while sliding.
			dash_Return();	// Make the astronaut dash.
		}	
	}

	if(e.keyCode == 40)		//down arrow key
	{
		//astronaut can duck at initial coordinates and when canSlide = true.
		if(canSlide && (astroLeft == 30 && astroBottom == 0)) 
		{
			slide();	//astronaut slides for 0.75 secs.
			let timerID = setTimeout(reset,750); //timerID stores the ID returned by setTimeout().
		}
	}
}

// Add an event listener to respond to the user pressing a directional key.
document.addEventListener("keydown", animate);