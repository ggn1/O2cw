const express = require('express');
const User = require('../emmyCore/user');
const router = express.Router();

const user = new User();

// Get the index.pug page*
router.get('/', (req, res, next) => {
    let user = req.session.user;
    // if user is already logged in redirect individual to home page*
    if(user) {
        res.redirect('/home');
        return;
    }
    // else send index page.*
    res.render('index', {title:"My application"});
})

// Retrieve home page*
router.get('/home', (req, res, next) => {
    let user = req.session.user;

    if(user) {
        res.render('home', {opp:req.session.opp, name:user.fullname});
        return;
    }
    res.redirect('/');
});

// Display login info 
router.post('/login', (req, res, next) => {
    user.login(req.body.username, req.body.password, function(result) {
        if(result) {
            req.session.user = result;
            req.session.opp = 1;
            res.redirect('/home');
        }else {
            res.send('Username/Password incorrect!');
        }
    })

});


router.post('/register', (req, res, next) => {
    let userInput = {
        username: req.body.username,
        fullname: req.body.fullname,
        password: req.body.password
    };
    user.create(userInput, function(lastId) {
        if(lastId) {
            user.find(lastId, function(result) {
                req.session.user = result;
                req.session.opp = 0;
                res.redirect('/home');
            });

        }else {
            console.log('Error creating a new user ...');
        }
    });

});


router.get('/loggout', (req, res, next) => {
    if(req.session.user) {
        req.session.destroy(function() {
            res.redirect('/');
        });
    }
});

module.exports = router;