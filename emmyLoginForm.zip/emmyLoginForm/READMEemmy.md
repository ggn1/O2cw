REFERENCE:

Nodejs - Building a Login/Register application [Internet]. Youtube.com; [Cited 13 nov 2019]. 
Available from: https://www.youtube.com/watch?v=S-nC83myMIs&list=PLhrKHgpbE1sjP2b2lQfcTIMetuh23UXAQ&index=5&t=0s




Enter "npm start" to launch then
Enter localhost port details into browser to try the form out



Use these queries to setup your own database:

```
CREATE DATABASE name;
```
```
USE name;
```
```
CREATE TABLE users (id int AUTO_INCREMENT, username varchar(20), fullname varchar(20), password varchar(128), PRIMARY KEY (id));
```