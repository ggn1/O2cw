const express = require('express');
const session = require('express-session');
const path = require('path');
const pageRouter = require('./emmyRoutes/pages');
const app = express();

// Collects user's input (body parser)*
app.use(express.urlencoded( { extended : false}));

// For javaScript and css files*
app.use(express.static(path.join(__dirname, 'emmyPublic')));

// Form skeleton (using pug not HTML)*
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'pug');

// session
app.use(session({
    secret:'youtube_video',
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 60 * 1000 * 30
    }
}));


// Routers*
app.use('/', pageRouter);

app.use((err, req, res, next) => {
    res.status(err.status || 500);
    res.send(err.message);
});

// Server*
app.listen(3002, () => { console.log('Server On Port: 3002');});

module.exports = app;