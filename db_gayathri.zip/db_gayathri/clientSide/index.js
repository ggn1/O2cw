var username;

// MAKE SOCKET CONNECTION
var socket = io.connect("http://localhost:3000");

function changeBody() {
    username = $("#nameInput").val();
    $("body").html("Welcome! <strong>" + username + "</strong>");
    socket.emit('addPlayerToDB', {name: username});
}

// EMIT EVENT
$('#joinButton').on('click', changeBody);
