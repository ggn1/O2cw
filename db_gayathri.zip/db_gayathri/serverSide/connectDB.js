var myHost = "localHost";
var myUser = "root";
var myPassword = "";
var myDatabase = "players";

var db = require('mysql');

var con = db.createConnection(
     {
        host:myHost,
        user:myUser,
        password:myPassword,
        database:myDatabase
    }
);

function connectToDB(){
    con.connect(function(err){
        if(!err) {
            console.log("Connected to db " + myDatabase + ".");    
        } else {
            console.log("Error connecting database.");    
        }
    });
}

function insertNameIntoTable(nameToAdd, recent){
    var myQuery = "INSERT INTO `players_table`(`recent`, `username`, `isAlive`) "
                + "VALUES ('" + recent +"'," + "'" + nameToAdd + "',1)";
    con.query(myQuery);
    console.log("inserted " + nameToAdd + " into table.");
}

function insertIdIntoTable(id){
    var myQuery = "UPDATE `players_table` SET `recent` = '',"
                    + "`socketId`= '" + id + "' WHERE `recent` = 'recent'";
    con.query(myQuery);
    console.log("updated socketId to " + id + " in table.");
}

function deleteFromTable(socketID){
    var myQuery = "DELETE FROM `players_table` WHERE socketId = '" 
                + socketID + "'";
    con.query(myQuery);
    console.log("deleted " + socketID + " from table.");
}

function getPlayerCount(){
    var myQuery = "SELECT COUNT(socketId) AS playersCount FROM players_table";
    var count = con.query(myQuery, function(err, result) {
        res = result[0].playersCount;
        console.log(result);
       });
    
}

module.exports.connectToDB = connectToDB;
module.exports.insertNameIntoTable = insertNameIntoTable;
module.exports.insertIdIntoTable = insertIdIntoTable;
module.exports.deleteFromTable = deleteFromTable;
module.exports.getPlayerCount = getPlayerCount;
