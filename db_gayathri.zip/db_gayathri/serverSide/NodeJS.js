// MODULES REQUIRED
const express = require('express');
const socket = require('socket.io');
const dbConnection = require('./connectDB');

// SETTING UP APP
const app = express();
var portNumber = 3000;

// STATIC FILES
app.use(express.static('../clientSide'));

// SERVER
const server = app.listen(portNumber, function(){
    console.log("Listening to port 3000")
});

// TO LOAD PAGE ON BROWSER
app.get('/', function(req, res){
    res.sendFile('D:/HWU/BACHELOR OF COMPUTER SCIENCE HONORS/YEAR 2/SEMESTER1/WEB PROGRAMMING/CourseWork/db_gayathri/clientSide/index.html');
});

app.get('/yo', function(req, res){
    res.send('Yo!');
});

app.get('/profile/:name', function(req, res){
    res.send('Profile id requested = ' + req.params.name);
});

// CONNECTING TO DB
dbConnection.connectToDB();

// SETTING UP SOCKET
var io = socket(server);
io.on('connection', function(socket){
    console.log("Made socket connection.", socket.id);

    socket.on('addPlayerToDB', function(data){
        console.log("Hey! I see you " + data.name + "!");
        dbConnection.insertIntoTable(data.name);
        // dbConnection.deleteFromTable(data.name);
    });
});
