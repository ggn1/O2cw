//function that causes the acid drop to fall
function aciddrop() 
{
  var p = 0;                   // intial position of drop
  var x = document.getElementById("obstaclefall");   //obstaclefall is id of the acid drop
  var y = setInterval(position, 3);    //calls function position() 

  //function to determine position of drop and stop or continue it from falling
  function position() 
 {

    if (p == 295)     //acid drop stops falling after 295px
    {
      clearInterval(y);      //stops setInterval() function from repeating
      
      picblink();            //calls function picblink() 
      if(document.getElementById)

      //hides the acid drop when the astronaut touches it
      document.getElementById("obstaclefall").style.visibility= "hidden";
    
      
    }

    else        //acid drop continues falling till 295px are covered
    {
      p++; 
      x.style.top = p + "px"; 
      x.style.down = p + "px"; 
     
    }

  }

}


//function that causes the astronaut to blink when acid touches
function picblink() 
{

  //astronauts fades
  function fade()
  {
    if(document.getElementById)
    document.getElementById("runningman").style.visibility= "hidden";

  }


  //astronaut appears
  function appear() 
  {
    if(document.getElementById)
    document.getElementById("runningman").style.visibility = "visible";
  }
  
  
  //calls fade() and appear() every 450 milliseconds 
  //ends after 2000 milliseconds
  for(var i=0; i < 2000; i=i+900)
{
	setTimeout(fade,i);
	setTimeout(appear,i+450);
}
}









