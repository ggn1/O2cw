function aciddrop() 
{
  var p = 0;
  var x = document.getElementById("obstaclefall");   //obstaclefall is id of the acid drop
  var y = setInterval(position, 3);    //calls function position() 
  function position() 
 {
    if (p == 295) 
    {
      clearInterval(y);     //acid drop stops falling after 295px
      picblink();            //calls function picblink() 
      
    }
    else        //acid drop continues falling till 295px are covered
    {
      p++; 
      x.style.top = p + "px"; 
      x.style.down = p + "px"; 
     
    }
  }
}


//function that causes the astronaut to blink when acid touches
function picblink() 
{

  //astronauts fades
  function fade()
  {
    if(document.getElementById)
    document.getElementById("runningman").style.visibility= "hidden";

  }


  //astronaut appears
  function appear() 
  {
    if(document.getElementById)
    document.getElementById("runningman").style.visibility = "visible";
  }
   
  //calls fade() and appear() every 450 milliseconds 
  //ends after 4500 milliseconds
  for(var i=0; i < 2000; i=i+900)
{
	setTimeout(fade,i);
	setTimeout(appear,i+450);
}


}




