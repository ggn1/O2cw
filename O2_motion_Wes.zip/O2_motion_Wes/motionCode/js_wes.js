var astroLeft = 30;	//stores the position of the astronaut from the left of the div (x-coord). The astronaut starts 30 px from the left of the div. 
var astroBottom = 0; //stores the position of the astronaut from the bottom of the div (y-coord) 
var astronaut = document.getElementById("astronaut");
var canSlide = true // variable to indicate if the astronaut can slide. Used to avoid spamming the down arrow key.
// Function to change the picture of the astronaut to him sliding and his dimensions. 
function slide()
{
	astronaut.src = "../images/slide.png";
	astronaut.style.height = 70 + "px";
	astronaut.style.width = 100 + "px";
	canSlide = false;	// sliding is blocked till the astronaut finishes sliding.
}
// Function to reset the astronaut's picture and dimensions after sliding.
function reset() 
{
	astronaut.src = "../images/running.gif";
	astronaut.style.height = 100 + "px";
	astronaut.style.width = 70 + "px";
	canSlide = true;	//the astronaut can slide again now
}
function animate(e)
{
	if(e.keyCode == 38)		//Up arrow key is pressed
	{
		if(astroBottom == 0 && astroLeft == 30)	// Up arrow key will work only if the y coord is zero and x coord is 30.
		{
				
				reset(); // This is to reset the astronaut if he suddenly jumps while sliding.
				/* 
				The ID value returned by setInterval() is used as the parameter for the clearInterval() method. Timer stores the ID value.
				The setInterval method calls jump every millisecond. 
				The timer variable must be declared before declaring the functions used in set interval.
				*/
			let timer = setInterval(jump,1);	//let specifies the scope of timer (It's a local variable).

			/**
				The astronaut's y-coord increases by 1 every millisecond till it reaches 150.
				Once y coord is 100 the descend function is called.
			*/
			function jump ()
			{
				//If the y-coord of the astronaut is 150 then stop the timer (stop executing the jump function).
				if(astroBottom == 150)
				{
					clearInterval(timer);
					timer = setInterval(descend,1);
				}				
				else
				{
					astroBottom++;	//increment the y-coord
					astronaut.style.bottom = astroBottom + "px"; //change the astornaut's y-coord 
				}

			}
			/**
				The astronaut's y-coord decreases by 1 every millisecond till it reaches 0.
			*/
			function descend()
			{
				
				if(astroBottom == 0)
					clearInterval(timer);
				else
				{
					astroBottom--;	//decrement the y-coord
					astronaut.style.bottom = astroBottom + "px"; //change the astornaut's y-coord
				}
			}	

		}

	}
	if(e.keyCode == 39)		//Right arrow key is pressed
	{
		if(astroLeft == 30 && astroBottom == 0)	// Right arrow key will work only if the x coord is 30 and y coord is zero.
		{
			/* Timer stores the value returned from the setInterval method.
				The setInterval method calls dash every five milliseconds. 
			*/
			let timer = setInterval(dash,5);
			/**
				The astronaut's x-coord increases by 1 every 5 millisecs till it reaches 150.
				Once x coord is 150 the returnBack function is called.
			*/
			function dash ()
			{
				//If the x-coord of the astronaut is 150 then stop the timer (stop executing the dash function).
				if(astroLeft == 150)
				{
					clearInterval(timer);
					timer = setInterval(returnBack,5);
				}				
				else
				{
					astroLeft++;	//increment the x-coord
					astronaut.style.left = astroLeft + "px"; //change the astornaut's x-coord 
				}

			}
			/**
				The astronaut's x-coord decreases by 1 every 5 millisecs till it reaches 0.
			*/
			function returnBack()
			{
				
				if(astroLeft == 30)
					clearInterval(timer);
				else
				{
					astroLeft--;	//decrement the x-coord
					astronaut.style.left = astroLeft + "px"; //change the astornaut's x-coord
				}
			}
			
		}
	}

	if(e.keyCode == 40)		//down arrow key
	{
		if(canSlide)	//astronaut can duck at initial coordinates and when canSlide = true;
		{
			
			if(astroLeft == 30 && astroBottom == 0 )
			{
				slide();	//astronaut slides for 0.75 secs.
				let timer = setTimeout(reset,750);
			}
		}
		
	}
}

document.onkeydown = animate;