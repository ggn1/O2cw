
var obstacles = ["url(../images_gayathri/rock.png)", "url(../images_gayathri/leech.png)"]

$(document).ready(setTimeout(move, 1000));

function move(){
		setTimeout(setRandomHeight, 1600);
		$(".obstacles").animate({right: '110%'}, 1500);
		setTimeout(reset, 1700);
}

function reset(){
	$(".obstacles").css("right", "0%");
	setTimeout(move, 1000);
}

function setRandomHeight(){
	let heightVal = Math.floor(Math.random()*31 + 50);
	let heightString = heightVal + "%";

	let imageVal = Math.floor(Math.random()*3);
	let imageString = obstacles [imageVal];

	$(".obstacles").css("background-image", imageString);

	$(".obstacles").css("top", heightString);
}