const express = require("express")
const app = require("express")();
const http = require("http").createServer(app);
const io = require("socket.io")(http);

app.get("/", function(req, res) {
 res.sendFile(__dirname + "/newSocketFinal.html");      //We have to pass the absolute path that is why we have use __dirname
 return
 });

 let count = 0;
 io.on('connection',function(socket){
    count++;
    console.log("user connected ");
    //socket.emit('testerEvent', { description: 'A custom event named testerEvent!'});
    console.log("Players Connected : "+ count );
    io.sockets.emit('broadcast',{ description: 'Players Connected - ' + count });

    socket.on('disconnect',function(event){
        count--;
        console.log("Number of Players left: " + count );
        io.sockets.emit('broadcast',{ description: 'Number of Players Left - ' + count });
    console.log("disconnected");
    })

    socket.on('clientEvent', function(data) {
        console.log(data);
        });
   });

http.listen(8080,function(){
    console.log("Server at 8080");
});