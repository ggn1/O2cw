var username;

// MAKE SOCKET CONNECTION
var socket = io.connect();
function changeBody() {
    username = $("#nameInput").val();
    $("body").html("Welcome! <strong>" + username + "</strong>"); 
    socket.emit('addPlayerToDB', {name: username});
}

// EMIT EVENT
$('#form1').submit(function(e){
    e.preventDefault();
    changeBody();
});
window.addEventListener('unload',function(e)
{
    console.log("Username: " + username);
    socket.emit('disconnect', {name: username});
});
