var myHost = "localHost";
var myUser = "root";
var myPassword = "";
var myDatabase = "players";

var db = require('mysql');

var con = db.createConnection(
     {
        host:myHost,
        user:myUser,
        password:myPassword,
        database:myDatabase
    }
);

function connectToDB(){
    con.connect(function(err){
        if(!err) {
            console.log("Connected to db " + myDatabase + ".");    
        } else {
            console.log("Error connecting database.");    
        }
    });
}

function insertIntoTable(nameToAdd){
    var myQuery = "INSERT INTO `players_table`(`username`, `isAlive`) "
                + "VALUES ('" + nameToAdd + "',true)";
    con.query(myQuery);
    console.log("inserted " + nameToAdd + " into table.");
}

function deleteFromTable(nameToDelete){
    var myQuery = "DELETE FROM `players_table` WHERE username = '" 
                + nameToDelete + "'";
    con.query(myQuery);
    console.log("deleted " + nameToDelete + " from table.");
}

function deletePlayerFromTable(playerName)
{
    con.query("delete from players_table where username = '" + playerName + "'", function(err, result)
    {
        if(err)
            throw err;
        console.log(result);
    });
}

function deleteDeadFromTable()
{
    con.query("delete from players_table where isAlive = false", function(err, result)
    {
        if(err)
            throw err;
        console.log(result);
    });
}

function selectCountFromTable()
{
    con.query("select count(*) from players_table", function(err, result)
    {
        if(err)
            throw err;
        console.log(result);
    });
}
module.exports.connectToDB = connectToDB;
module.exports.insertIntoTable = insertIntoTable;
module.exports.deleteFromTable = deleteFromTable;
module.exports.deletePlayerFromTable = deletePlayerFromTable;
module.exports.deleteDeadFromTable = deleteDeadFromTable;
module.exports.selectCountFromTable = selectCountFromTable;
